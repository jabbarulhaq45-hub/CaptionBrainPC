from __future__ import annotations
import json, time
from pathlib import Path
from captionbrain.config import PLANS_DIR, CALIBRATION_DIR
from captionbrain.models import EditPlan

class PlanStore:
    @staticmethod
    def save(plan: EditPlan) -> Path:
        stamp = time.strftime("%Y%m%d_%H%M%S")
        path = PLANS_DIR / f"plan_{stamp}.json"
        path.write_text(json.dumps(plan.to_dict(), indent=2, ensure_ascii=False), encoding="utf-8")
        (PLANS_DIR / "latest.json").write_text(json.dumps(plan.to_dict(), indent=2, ensure_ascii=False), encoding="utf-8")
        return path

    @staticmethod
    def latest_dict():
        p = PLANS_DIR / "latest.json"
        if not p.exists():
            return None
        return json.loads(p.read_text(encoding="utf-8"))

class CalibrationStore:
    @staticmethod
    def save(data: dict, profile="default") -> Path:
        p = CALIBRATION_DIR / f"{profile}.json"
        p.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
        return p

    @staticmethod
    def load(profile="default"):
        p = CALIBRATION_DIR / f"{profile}.json"
        if not p.exists():
            return None
        return json.loads(p.read_text(encoding="utf-8"))
