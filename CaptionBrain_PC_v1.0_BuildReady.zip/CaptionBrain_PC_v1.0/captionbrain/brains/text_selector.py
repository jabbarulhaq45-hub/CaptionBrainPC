from __future__ import annotations
import re
from typing import List, Tuple
from captionbrain.models import TranscriptSegment

STOP = {"the","a","an","and","or","but","to","of","in","on","at","for","with","is","are","was","were","be","been","being","this","that","it","as","by","from","we","you","i","they","he","she","so","just","very","really"}
NEG = {"no","not","never","wrong","error","fail","failed","danger","destroy","stop","bad","problem","issue","mistake"}
IMPACT = {"best","first","secret","important","must","only","now","today","biggest","million","billion","warning","truth","why","how","what"}

class TextSelectorAgent:
    def _clean(self, w:str):
        return re.sub(r"[^\w'’-]", "", w, flags=re.UNICODE).strip()

    def select(self, seg: TranscriptSegment):
        words = [self._clean(w.text) for w in seg.words] if seg.words else self._clean(seg.text).split()
        words = [w for w in words if w]
        if not words:
            return []
        scored=[]
        for i,w in enumerate(words):
            lw=w.lower()
            score=0.5
            if lw not in STOP: score+=0.6
            if lw in NEG: score+=1.5
            if lw in IMPACT: score+=1.0
            if len(w)>=7: score+=0.35
            if any(ch.isdigit() for ch in w): score+=0.7
            if w.isupper() and len(w)>1: score+=0.7
            scored.append((score,i,w))
        # choose a compact exact phrase around the strongest word, never paraphrase
        scored.sort(reverse=True)
        _, idx, _ = scored[0]
        left=max(0,idx-1); right=min(len(words),idx+2)
        phrase=words[left:right]
        if len(words)<=4: phrase=words
        return phrase[:4]

    def semantic_flags(self, text:str):
        toks={self._clean(x).lower() for x in text.split()}
        return {
            "negative": bool(toks & NEG),
            "impact": bool(toks & IMPACT),
            "question": "?" in text,
            "short": len([x for x in toks if x]) <= 2,
        }
