class MotionAgent:
    def choose(self, style_id:str, flags:dict):
        if style_id=="ERROR_GLOW": return "FLICKER_STRIKE"
        if style_id=="STACKED_KINETIC": return "GLOW_SLIDE_UP"
        if style_id=="IMPACT_ONE": return "PUNCH_SCALE"
        return "SOFT_SLIDE_UP"
