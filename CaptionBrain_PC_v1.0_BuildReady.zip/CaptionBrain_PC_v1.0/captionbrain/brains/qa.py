from __future__ import annotations
import re

class QualityAgent:
    def verify(self, event_text:str, transcript_text:str, font_size:int, start:float, end:float):
        norm=lambda s: re.sub(r"\s+"," ",re.sub(r"[^\w'’-]+"," ",s.lower())).strip()
        exact = norm(event_text) in norm(transcript_text)
        duration=max(0.01,end-start)
        readable = (len(event_text)/duration) < 34
        size_ok = 24 <= font_size <= 160
        return {"exact_transcript_substring": exact, "readable_rate": readable, "font_size_ok": size_ok, "pass": exact and readable and size_ok}
