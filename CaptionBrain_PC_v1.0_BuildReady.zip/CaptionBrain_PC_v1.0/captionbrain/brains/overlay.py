class OverlayAgent:
    def choose(self, style_id:str, flags:dict):
        if style_id=="ERROR_GLOW": return "strike_line"
        if flags.get("impact") and style_id=="STACKED_KINETIC": return "none"
        return "none"
