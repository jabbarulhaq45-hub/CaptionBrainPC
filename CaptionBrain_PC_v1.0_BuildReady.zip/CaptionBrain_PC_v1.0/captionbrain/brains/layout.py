from __future__ import annotations
from captionbrain.models import SceneInfo

class LayoutAgent:
    PREFERENCE=["top_left","top_right","mid_left","mid_right","lower_center","top_center","lower_left","lower_right"]
    def choose(self, scene: SceneInfo|None, flags:dict):
        if scene and scene.frames:
            agg={}
            for fr in scene.frames:
                for k,v in fr.zone_scores.items(): agg[k]=agg.get(k,0)+v
            n=max(1,len(scene.frames))
            agg={k:v/n for k,v in agg.items()}
            safe=min(agg,key=agg.get) if agg else "lower_center"
        else:
            safe="lower_center"
        if flags.get("short") and safe in {"top_left","top_right","mid_left","mid_right"}:
            return "ONE_ON_ONE", safe
        if flags.get("impact"):
            return "CLUSTER", safe
        return "STRAIGHT_LINE", safe
