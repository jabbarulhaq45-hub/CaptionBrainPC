from __future__ import annotations

class TypographyAgent:
    def choose(self, flags:dict, layout:str):
        if flags.get("negative"):
            return {"style_id":"ERROR_GLOW","font":"Arial Black","size":76,"weight":"900","effect":"red_glow"}
        if layout=="CLUSTER":
            return {"style_id":"STACKED_KINETIC","font":"Inter","size":72,"weight":"800","effect":"subtle_shadow"}
        if layout=="ONE_ON_ONE":
            return {"style_id":"IMPACT_ONE","font":"Arial Black","size":94,"weight":"900","effect":"clean"}
        return {"style_id":"CLEAN_EDITORIAL","font":"Helvetica","size":62,"weight":"700","effect":"clean"}
