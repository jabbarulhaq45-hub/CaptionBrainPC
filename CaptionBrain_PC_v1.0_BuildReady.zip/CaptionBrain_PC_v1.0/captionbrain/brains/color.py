from __future__ import annotations
from captionbrain.models import SceneInfo

class ColorAgent:
    def choose(self, scene: SceneInfo|None, flags:dict):
        brightness=0.5
        if scene and scene.frames:
            brightness=sum(f.brightness for f in scene.frames)/len(scene.frames)
        if flags.get("negative"):
            return ("#FF3333" if brightness<0.55 else "#B00020"), None, "none"
        if brightness>0.62:
            return "#111111", "#1E64FF" if flags.get("impact") else None, "none"
        return "#FFFFFF", "#FFD400" if flags.get("impact") else None, "shadow"
