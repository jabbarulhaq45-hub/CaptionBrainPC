from __future__ import annotations
from typing import List
from captionbrain.models import TranscriptSegment, SceneInfo, CaptionEvent
from captionbrain.brains.text_selector import TextSelectorAgent
from captionbrain.brains.layout import LayoutAgent
from captionbrain.brains.color import ColorAgent
from captionbrain.brains.typography import TypographyAgent
from captionbrain.brains.motion import MotionAgent
from captionbrain.brains.overlay import OverlayAgent
from captionbrain.brains.qa import QualityAgent

class DirectorAgent:
    def __init__(self):
        self.text=TextSelectorAgent(); self.layout=LayoutAgent(); self.color=ColorAgent()
        self.type=TypographyAgent(); self.motion=MotionAgent(); self.overlay=OverlayAgent(); self.qa=QualityAgent()

    def _scene_for(self, scenes:List[SceneInfo], t:float):
        for s in scenes:
            if s.start <= t < s.end: return s
        return scenes[-1] if scenes else None

    def plan(self, transcript:List[TranscriptSegment], scenes:List[SceneInfo], duration:float):
        events=[]
        for seg in transcript:
            phrase_words=self.text.select(seg)
            if not phrase_words: continue
            phrase=" ".join(phrase_words)
            flags=self.text.semantic_flags(phrase)
            scene=self._scene_for(scenes,(seg.start+seg.end)/2)
            layout,position=self.layout.choose(scene,flags)
            typo=self.type.choose(flags,layout)
            color,accent,bg=self.color.choose(scene,flags)
            motion=self.motion.choose(typo["style_id"],flags)
            overlay=self.overlay.choose(typo["style_id"],flags)
            # timing: keep exact spoken segment but cap long captions to a readable beat
            start=seg.start; end=min(seg.end, seg.start+max(0.65,min(2.4,0.38*len(phrase_words)+0.45)))
            qa=self.qa.verify(phrase,seg.text,typo["size"],start,end)
            events.append(CaptionEvent(
                start=start,end=end,text=phrase,transcript_text=seg.text,
                style_id=typo["style_id"],layout=layout,font_family=typo["font"],font_size=typo["size"],font_weight=typo["weight"],
                text_color=color,accent_color=accent,background_style=bg,position=position,motion=motion,effect=typo["effect"],
                reason=f"tutorial-brain selection; flags={flags}; overlay={overlay}",qa=qa
            ))
        return events
