from __future__ import annotations
from pathlib import Path
import os, json

APP_NAME = "CaptionBrain"
LOCAL_DATA = Path(os.getenv("LOCALAPPDATA", Path.home() / "AppData/Local")) / APP_NAME
PLANS_DIR = LOCAL_DATA / "plans"
CALIBRATION_DIR = LOCAL_DATA / "calibration"
LOG_DIR = LOCAL_DATA / "logs"
CACHE_DIR = LOCAL_DATA / "cache"
for p in [LOCAL_DATA, PLANS_DIR, CALIBRATION_DIR, LOG_DIR, CACHE_DIR]:
    p.mkdir(parents=True, exist_ok=True)

ROOT = Path(__file__).resolve().parent.parent
ASSETS = ROOT / "assets"
RESOURCES = ROOT / "resources"
KNOWLEDGE_FILE = ASSETS / "knowledge" / "tutorial_brain.json"
STYLE_FILE = ASSETS / "knowledge" / "style_recipes.json"
CALIBRATION_TARGETS = ASSETS / "knowledge" / "calibration_targets.json"
MASTER_PDF = ASSETS / "knowledge" / "CaptionBrain_Master_Tutorial_Brain_v1.pdf"

DEFAULTS = {
    "whisper_model": "small",
    "whisper_device": "auto",
    "beam_size": 5,
    "language": None,
    "frame_sample_seconds": 1.0,
    "strict_caption_only": True,
    "capcut_path": "",
    "calibration_profile": "default",
    "safe_mode": True,
}

SETTINGS_FILE = LOCAL_DATA / "settings.json"

def load_settings():
    data = DEFAULTS.copy()
    if SETTINGS_FILE.exists():
        try:
            data.update(json.loads(SETTINGS_FILE.read_text(encoding="utf-8")))
        except Exception:
            pass
    return data

def save_settings(data):
    SETTINGS_FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")
