from __future__ import annotations
from pathlib import Path
import json, threading, traceback
from PySide6.QtCore import Qt, Signal, QObject
from PySide6.QtWidgets import (
    QMainWindow,QWidget,QVBoxLayout,QHBoxLayout,QPushButton,QLabel,QFileDialog,
    QStackedWidget,QListWidget,QListWidgetItem,QTextEdit,QTableWidget,QTableWidgetItem,
    QProgressBar,QLineEdit,QComboBox,QSpinBox,QCheckBox,QMessageBox,QFrame
)
from captionbrain.analysis.pipeline import AnalysisPipeline
from captionbrain.storage.database import PlanStore, CalibrationStore
from captionbrain.capcut.calibration import CalibrationEngine
from captionbrain.capcut.launcher import CapCutLauncher
from captionbrain.capcut.executor import CapCutExecutor
from captionbrain.config import load_settings, save_settings

class Bus(QObject):
    status=Signal(str)
    plan_ready=Signal(object)
    calibration_ready=Signal(object)
    error=Signal(str)
    edit_done=Signal()

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("CaptionBrain PC v1.0")
        self.resize(1180,760)
        self.bus=Bus(); self.video_path=""; self.plan=None; self.executor=None
        self.bus.status.connect(self.on_status); self.bus.plan_ready.connect(self.on_plan); self.bus.calibration_ready.connect(self.on_calibration)
        self.bus.error.connect(self.on_error); self.bus.edit_done.connect(lambda: self.on_status("Editing finished"))
        self._build()

    def _build(self):
        root=QWidget(); self.setCentralWidget(root); layout=QVBoxLayout(root)
        top=QHBoxLayout(); self.status_label=QLabel("No Video"); self.status_label.setStyleSheet("font-weight:700;padding:8px;background:#20242b;color:white;border-radius:6px")
        top.addWidget(QLabel("CaptionBrain")); top.addStretch(); top.addWidget(self.status_label); layout.addLayout(top)
        body=QHBoxLayout(); layout.addLayout(body,1)
        self.nav=QListWidget(); self.nav.setFixedWidth(190)
        for name in ["Home","Analyze Video","Edit Plan","CapCut Learn","Start Editing","History","Settings"]: self.nav.addItem(QListWidgetItem(name))
        body.addWidget(self.nav)
        self.stack=QStackedWidget(); body.addWidget(self.stack,1)
        self.stack.addWidget(self._home()); self.stack.addWidget(self._analyze()); self.stack.addWidget(self._plan()); self.stack.addWidget(self._learn()); self.stack.addWidget(self._edit()); self.stack.addWidget(self._history()); self.stack.addWidget(self._settings())
        self.nav.currentRowChanged.connect(self.stack.setCurrentIndex); self.nav.setCurrentRow(0)

    def card(self,title,body):
        w=QFrame(); w.setFrameShape(QFrame.StyledPanel); l=QVBoxLayout(w); h=QLabel(title); h.setStyleSheet("font-size:18px;font-weight:700"); l.addWidget(h); l.addWidget(QLabel(body)); return w,l

    def _home(self):
        w=QWidget(); l=QVBoxLayout(w); c,cl=self.card("1. Import the finished video","Use the same video later inside your CapCut project. CaptionBrain analyzes it locally before editing.")
        self.video_label=QLabel("No video selected"); b=QPushButton("IMPORT VIDEO"); b.clicked.connect(self.pick_video); cl.addWidget(self.video_label); cl.addWidget(b); l.addWidget(c)
        c2,c2l=self.card("Daily workflow","Import video → Analyze → wait for READY → open same video in CapCut → press START AI EDITING. Final captions are manually typed text layers, not Auto Captions."); l.addWidget(c2); l.addStretch(); return w

    def _analyze(self):
        w=QWidget(); l=QVBoxLayout(w); self.analysis_info=QLabel("Import a video first."); self.analysis_info.setWordWrap(True); l.addWidget(self.analysis_info)
        self.progress=QProgressBar(); self.progress.setRange(0,0); self.progress.hide(); l.addWidget(self.progress)
        b=QPushButton("ANALYZE FULL VIDEO"); b.clicked.connect(self.start_analysis); l.addWidget(b)
        self.analysis_log=QTextEdit(); self.analysis_log.setReadOnly(True); l.addWidget(self.analysis_log,1); return w

    def _plan(self):
        w=QWidget(); l=QVBoxLayout(w); l.addWidget(QLabel("AI Edit Plan — exact transcript words only")); self.plan_table=QTableWidget(0,10); self.plan_table.setHorizontalHeaderLabels(["Start","End","Text","Style","Layout","Font","Size","Color","Position","Motion"]); l.addWidget(self.plan_table,1); return w

    def _learn(self):
        w=QWidget(); l=QVBoxLayout(w); intro=QLabel("One-time CapCut Learn Mode. CaptionBrain launches your installed CapCut, scans UI Automation + OCR labels, generates a 30-second calibration asset, and stores a verified control map. Re-run after major CapCut updates."); intro.setWordWrap(True); l.addWidget(intro)
        self.learn_status=QLabel("Calibration not run yet"); l.addWidget(self.learn_status)
        b=QPushButton("RUN FULL CAPCUT CALIBRATION"); b.clicked.connect(self.start_calibration); l.addWidget(b)
        self.learn_log=QTextEdit(); self.learn_log.setReadOnly(True); l.addWidget(self.learn_log,1); return w

    def _edit(self):
        w=QWidget(); l=QVBoxLayout(w); self.preflight=QLabel("Required: Edit Plan READY + CapCut calibration + same video already placed in the CapCut project."); self.preflight.setWordWrap(True); l.addWidget(self.preflight)
        h=QHBoxLayout(); start=QPushButton("START AI EDITING"); pause=QPushButton("PAUSE"); resume=QPushButton("RESUME"); stop=QPushButton("STOP"); start.clicked.connect(self.start_editing); pause.clicked.connect(lambda: self.executor and self.executor.pause()); resume.clicked.connect(lambda: self.executor and self.executor.resume()); stop.clicked.connect(lambda: self.executor and self.executor.stop());
        for b in [start,pause,resume,stop]: h.addWidget(b)
        l.addLayout(h); self.edit_log=QTextEdit(); self.edit_log.setReadOnly(True); l.addWidget(self.edit_log,1); return w

    def _history(self):
        w=QWidget(); l=QVBoxLayout(w); l.addWidget(QLabel("Plans and calibration profiles are stored under %LOCALAPPDATA%\\CaptionBrain.")); refresh=QPushButton("REFRESH LATEST PLAN"); refresh.clicked.connect(lambda: self.on_plan(PlanStore.latest_dict())); l.addWidget(refresh); l.addStretch(); return w

    def _settings(self):
        w=QWidget(); l=QVBoxLayout(w); s=load_settings();
        l.addWidget(QLabel("Speech model (small is bundled by default; medium/large can be added later for more accuracy)")); self.model_box=QComboBox(); self.model_box.addItems(["small","medium","large-v3"]); self.model_box.setCurrentText(s.get("whisper_model","small")); l.addWidget(self.model_box)
        l.addWidget(QLabel("CapCut executable or shortcut path (optional; auto-detection runs first)")); self.capcut_path=QLineEdit(s.get("capcut_path","")); l.addWidget(self.capcut_path)
        self.strict=QCheckBox("Strict caption-only mode: block AI image/text-to-image screens"); self.strict.setChecked(True); l.addWidget(self.strict)
        save=QPushButton("SAVE SETTINGS"); save.clicked.connect(self.save_settings_ui); l.addWidget(save); l.addStretch(); return w

    def pick_video(self):
        p,_=QFileDialog.getOpenFileName(self,"Select video","","Videos (*.mp4 *.mov *.mkv *.avi *.webm);;All files (*.*)")
        if p:
            self.video_path=p; self.video_label.setText(p); self.analysis_info.setText(f"Ready to analyze: {Path(p).name}"); self.status_label.setText("Video Loaded")

    def start_analysis(self):
        if not self.video_path: return self.on_error("Import a video first.")
        self.progress.show(); self.analysis_log.clear(); self.status_label.setText("Analyzing")
        def work():
            try:
                pipe=AnalysisPipeline(lambda x:self.bus.status.emit(x)); plan=pipe.run(self.video_path); self.bus.plan_ready.emit(plan)
            except Exception: self.bus.error.emit(traceback.format_exc())
        threading.Thread(target=work,daemon=True).start()

    def start_calibration(self):
        self.learn_log.clear(); self.status_label.setText("Learning CapCut")
        def work():
            try:
                e=CalibrationEngine(lambda x:self.bus.status.emit("CAL: "+x)); data=e.run(); self.bus.calibration_ready.emit(data)
            except Exception: self.bus.error.emit(traceback.format_exc())
        threading.Thread(target=work,daemon=True).start()

    def start_editing(self):
        plan=self.plan.to_dict() if hasattr(self.plan,"to_dict") else (self.plan or PlanStore.latest_dict())
        if not plan: return self.on_error("Analyze a video first. No Edit Plan exists.")
        if not CalibrationStore.load(): return self.on_error("Run CapCut Learn calibration first.")
        self.status_label.setText("Editing")
        def work():
            try:
                self.executor=CapCutExecutor(lambda x:self.bus.status.emit("EDIT: "+x)); self.executor.execute_dict(plan); self.bus.edit_done.emit()
            except Exception: self.bus.error.emit(traceback.format_exc())
        threading.Thread(target=work,daemon=True).start()

    def on_status(self,text):
        self.status_label.setText(text)
        if text.startswith("CAL:"): self.learn_log.append(text[4:])
        elif text.startswith("EDIT:"): self.edit_log.append(text[5:])
        else: self.analysis_log.append(text)

    def on_plan(self,plan):
        if plan is None: return
        self.plan=plan; self.progress.hide(); self.status_label.setText("READY FOR CAPCUT")
        data=plan.to_dict() if hasattr(plan,"to_dict") else plan; events=data.get("events",[]); self.plan_table.setRowCount(len(events))
        for r,e in enumerate(events):
            vals=[f"{e.get('start',0):.2f}",f"{e.get('end',0):.2f}",e.get('text',''),e.get('style_id',''),e.get('layout',''),e.get('font_family',''),str(e.get('font_size','')),e.get('text_color',''),e.get('position',''),e.get('motion','')]
            for c,v in enumerate(vals): self.plan_table.setItem(r,c,QTableWidgetItem(str(v)))
        self.nav.setCurrentRow(2)

    def on_calibration(self,data):
        self.learn_status.setText(f"{data.get('status')} — {data.get('targets_found')}/{data.get('targets_total')} controls mapped. Demo asset: {data.get('demo_asset')}")
        self.status_label.setText("CapCut Learned")

    def on_error(self,msg):
        self.progress.hide(); self.status_label.setText("Error"); QMessageBox.critical(self,"CaptionBrain",msg[-4000:])

    def save_settings_ui(self):
        s=load_settings(); s["whisper_model"]=self.model_box.currentText(); s["capcut_path"]=self.capcut_path.text().strip(); s["strict_caption_only"]=self.strict.isChecked(); save_settings(s); QMessageBox.information(self,"CaptionBrain","Settings saved.")
