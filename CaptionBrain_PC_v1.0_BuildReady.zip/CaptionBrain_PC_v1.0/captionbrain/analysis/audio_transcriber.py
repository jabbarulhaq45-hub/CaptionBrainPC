from __future__ import annotations
from pathlib import Path
import subprocess, tempfile, difflib, os
from typing import Callable, List, Tuple
from rapidfuzz.fuzz import ratio
import imageio_ffmpeg
from faster_whisper import WhisperModel
from captionbrain.models import TranscriptSegment, WordToken
from captionbrain.config import RESOURCES

class AudioTranscriber:
    def __init__(self, model_name="small", device="auto", beam_size=5, language=None):
        self.model_name = model_name
        self.device = device
        self.beam_size = beam_size
        self.language = language
        self._model = None

    def _model_path(self):
        bundled = RESOURCES / "models" / f"faster-whisper-{self.model_name}"
        return str(bundled) if bundled.exists() and any(bundled.iterdir()) else self.model_name

    def _resolve_device(self):
        if self.device != "auto":
            return self.device, "float16" if self.device == "cuda" else "int8"
        try:
            import ctranslate2
            if ctranslate2.get_cuda_device_count() > 0:
                return "cuda", "float16"
        except Exception:
            pass
        return "cpu", "int8"

    def _get_model(self):
        if self._model is None:
            dev, compute = self._resolve_device()
            self._model = WhisperModel(self._model_path(), device=dev, compute_type=compute)
        return self._model

    def extract_wav(self, video_path: str) -> str:
        ffmpeg = imageio_ffmpeg.get_ffmpeg_exe()
        out = str(Path(tempfile.gettempdir()) / "captionbrain_audio_16k.wav")
        cmd = [ffmpeg, "-y", "-i", video_path, "-vn", "-ac", "1", "-ar", "16000", "-c:a", "pcm_s16le", out]
        subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True)
        return out

    def _pass(self, wav_path: str, condition_previous: bool):
        model = self._get_model()
        segments, info = model.transcribe(
            wav_path,
            beam_size=self.beam_size,
            word_timestamps=True,
            vad_filter=True,
            language=self.language,
            condition_on_previous_text=condition_previous,
            temperature=0.0,
        )
        out = []
        for seg in segments:
            words = []
            probs = []
            for w in (seg.words or []):
                txt = (w.word or "").strip()
                if not txt:
                    continue
                p = float(getattr(w, "probability", 1.0) or 1.0)
                probs.append(p)
                words.append(WordToken(txt, float(w.start), float(w.end), p))
            conf = sum(probs)/len(probs) if probs else 0.85
            out.append(TranscriptSegment(float(seg.start), float(seg.end), (seg.text or "").strip(), words, conf))
        return out, getattr(info, "language", self.language or "unknown")

    def _merge_consensus(self, a: List[TranscriptSegment], b: List[TranscriptSegment]):
        # Maximum-confirmation strategy: keep pass A timing but attach verification score from pass B text overlap.
        b_text = " ".join(x.text for x in b).strip()
        for seg in a:
            if not seg.text:
                continue
            window_score = ratio(seg.text.lower(), b_text.lower()) / 100.0 if b_text else 0.0
            seg.confidence = max(0.0, min(1.0, (seg.confidence * 0.75) + (window_score * 0.25)))
        return a

    def transcribe(self, video_path: str, progress: Callable[[str],None] | None = None) -> Tuple[List[TranscriptSegment], str]:
        progress = progress or (lambda _: None)
        progress("Extracting audio…")
        wav = self.extract_wav(video_path)
        progress("Transcribing pass 1…")
        a, lang = self._pass(wav, True)
        progress("Verifying transcript with pass 2…")
        b, _ = self._pass(wav, False)
        merged = self._merge_consensus(a, b)
        return merged, lang
