from __future__ import annotations
import cv2, math
import numpy as np
from pathlib import Path
from typing import Callable, List
from captionbrain.models import VisualFrameInfo, SceneInfo

ZONES = {
    "top_left": (0.05,0.06,0.45,0.34),
    "top_center": (0.27,0.05,0.73,0.33),
    "top_right": (0.55,0.06,0.95,0.34),
    "mid_left": (0.05,0.30,0.45,0.68),
    "mid_right": (0.55,0.30,0.95,0.68),
    "lower_left": (0.05,0.62,0.45,0.92),
    "lower_center": (0.27,0.62,0.73,0.92),
    "lower_right": (0.55,0.62,0.95,0.92),
}

class VideoAnalyzer:
    def __init__(self, sample_seconds=1.0):
        self.sample_seconds = max(0.25, float(sample_seconds))
        haar = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
        self.face = cv2.CascadeClassifier(haar)

    def _zone_score(self, frame, gray, faces, rect):
        h,w = gray.shape
        x0,y0,x1,y1 = rect
        xa,ya,xb,yb = int(x0*w),int(y0*h),int(x1*w),int(y1*h)
        roi = gray[ya:yb, xa:xb]
        if roi.size == 0: return 999.0
        edges = cv2.Canny(roi, 70, 140)
        edge = float(edges.mean()/255.0)
        variance = float(roi.std()/64.0)
        face_penalty = 0.0
        for fx,fy,fw,fh in faces:
            cx,cy = fx+fw/2, fy+fh/2
            if xa <= cx <= xb and ya <= cy <= yb:
                face_penalty += 3.0
        return edge*1.7 + variance*0.8 + face_penalty

    def analyze(self, video_path: str, progress: Callable[[str],None] | None=None):
        progress = progress or (lambda _: None)
        cap = cv2.VideoCapture(video_path)
        if not cap.isOpened():
            raise RuntimeError("Could not open video")
        fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
        frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
        duration = frames / fps if frames else 0.0
        step = max(1, int(fps*self.sample_seconds))
        infos: List[VisualFrameInfo] = []
        hist_prev = None
        cut_times = [0.0]
        idx = 0
        while True:
            cap.set(cv2.CAP_PROP_POS_FRAMES, idx)
            ok, frame = cap.read()
            if not ok: break
            t = idx/fps
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            small = cv2.resize(gray, None, fx=0.5, fy=0.5)
            faces = self.face.detectMultiScale(small, 1.2, 4, minSize=(30,30))
            faces = [[int(x*2),int(y*2),int(w*2),int(h*2)] for x,y,w,h in faces]
            edges = cv2.Canny(gray,70,140)
            brightness = float(gray.mean()/255.0)
            edge_density = float(edges.mean()/255.0)
            mean_bgr = frame.reshape(-1,3).mean(axis=0)
            rgb = [int(mean_bgr[2]),int(mean_bgr[1]),int(mean_bgr[0])]
            zs = {name: self._zone_score(frame, gray, faces, rect) for name,rect in ZONES.items()}
            infos.append(VisualFrameInfo(t, brightness, edge_density, faces, zs, rgb))
            hist = cv2.calcHist([cv2.resize(frame,(160,90))],[0,1],None,[16,16],[0,256,0,256])
            cv2.normalize(hist,hist)
            if hist_prev is not None:
                diff = cv2.compareHist(hist_prev,hist,cv2.HISTCMP_BHATTACHARYYA)
                if diff > 0.48 and (t-cut_times[-1]) > 0.75:
                    cut_times.append(t)
            hist_prev = hist
            if len(infos)%10==0: progress(f"Visual analysis {min(100,int((t/max(duration,0.1))*100))}%")
            idx += step
            if duration and t >= duration: break
        cap.release()
        if duration and (not cut_times or cut_times[-1] < duration): cut_times.append(duration)
        scenes=[]
        for i in range(len(cut_times)-1):
            s,e=cut_times[i],cut_times[i+1]
            fs=[f for f in infos if s <= f.time < e]
            rep=(s+e)/2
            scenes.append(SceneInfo(s,e,rep,fs))
        return duration, scenes
