from __future__ import annotations
from typing import Callable
from captionbrain.analysis.audio_transcriber import AudioTranscriber
from captionbrain.analysis.video_analyzer import VideoAnalyzer
from captionbrain.brains.director import DirectorAgent
from captionbrain.config import load_settings
from captionbrain.models import EditPlan
from captionbrain.storage.database import PlanStore

class AnalysisPipeline:
    def __init__(self, progress: Callable[[str],None] | None=None):
        self.progress = progress or (lambda _: None)
        self.settings = load_settings()

    def run(self, video_path: str) -> EditPlan:
        self.progress("Starting full analysis…")
        va = VideoAnalyzer(self.settings.get("frame_sample_seconds",1.0))
        duration, scenes = va.analyze(video_path, self.progress)
        tr = AudioTranscriber(
            self.settings.get("whisper_model","small"),
            self.settings.get("whisper_device","auto"),
            self.settings.get("beam_size",5),
            self.settings.get("language")
        )
        transcript, language = tr.transcribe(video_path, self.progress)
        self.progress("Running specialist brains…")
        director = DirectorAgent()
        events = director.plan(transcript, scenes, duration)
        plan = EditPlan(video_path, duration, language, transcript, scenes, events,
                        {"status":"READY", "transcript_policy":"exact_substrings_only", "planner":"multi-agent tutorial brain v1"})
        PlanStore.save(plan)
        self.progress("READY FOR CAPCUT")
        return plan
