from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import List, Dict, Any, Optional

@dataclass
class WordToken:
    text: str
    start: float
    end: float
    probability: float = 1.0

@dataclass
class TranscriptSegment:
    start: float
    end: float
    text: str
    words: List[WordToken] = field(default_factory=list)
    confidence: float = 1.0

@dataclass
class VisualFrameInfo:
    time: float
    brightness: float
    edge_density: float
    face_boxes: List[List[int]] = field(default_factory=list)
    zone_scores: Dict[str, float] = field(default_factory=dict)
    dominant_rgb: List[int] = field(default_factory=lambda: [127,127,127])

@dataclass
class SceneInfo:
    start: float
    end: float
    representative_time: float
    frames: List[VisualFrameInfo] = field(default_factory=list)

@dataclass
class CaptionEvent:
    start: float
    end: float
    text: str
    transcript_text: str
    style_id: str
    layout: str
    font_family: str
    font_size: int
    font_weight: str
    text_color: str
    accent_color: Optional[str]
    background_style: str
    position: str
    motion: str
    effect: str
    reason: str
    source_word_indexes: List[int] = field(default_factory=list)
    qa: Dict[str, Any] = field(default_factory=dict)

@dataclass
class EditPlan:
    video_path: str
    duration: float
    language: str
    transcript: List[TranscriptSegment]
    scenes: List[SceneInfo]
    events: List[CaptionEvent]
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self):
        return asdict(self)
