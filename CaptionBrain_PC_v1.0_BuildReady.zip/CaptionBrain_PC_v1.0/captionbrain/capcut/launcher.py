from __future__ import annotations
from pathlib import Path
import os, subprocess, time
from captionbrain.config import load_settings, save_settings

KNOWN = [
    Path(os.getenv("LOCALAPPDATA", "")) / "CapCut" / "Apps" / "CapCut.exe",
    Path(os.getenv("LOCALAPPDATA", "")) / "Programs" / "CapCut" / "CapCut.exe",
    Path(os.getenv("PROGRAMFILES", "C:/Program Files")) / "CapCut" / "CapCut.exe",
]

class CapCutLauncher:
    def find(self):
        settings=load_settings()
        configured=settings.get("capcut_path","")
        if configured and Path(configured).exists(): return Path(configured)
        for p in KNOWN:
            if p and p.exists(): return p
        # Desktop/start menu shortcut fallback.
        homes=[Path.home()/"Desktop", Path(os.getenv("APPDATA",""))/"Microsoft/Windows/Start Menu/Programs"]
        for base in homes:
            if not base.exists(): continue
            for p in base.rglob("*CapCut*.lnk"):
                return p
        return None

    def launch(self):
        p=self.find()
        if not p: raise FileNotFoundError("CapCut was not found. Set its path in Settings.")
        if p.suffix.lower()==".lnk": os.startfile(str(p))
        else: subprocess.Popen([str(p)], close_fds=True)
        return str(p)
