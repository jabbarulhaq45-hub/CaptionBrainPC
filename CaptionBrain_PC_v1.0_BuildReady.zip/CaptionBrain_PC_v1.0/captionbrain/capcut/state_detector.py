from __future__ import annotations

PROHIBITED = ["ai image","text to image","image generator","generate image","ai generated image"]

class StateDetector:
    def __init__(self, uia): self.uia=uia
    def texts(self):
        return " | ".join((c.get("name") or "").lower() for c in self.uia.snapshot_controls() if c.get("name"))
    def prohibited_state(self):
        t=self.texts()
        return next((x for x in PROHIBITED if x in t),None)
    def expected_any(self, labels):
        t=self.texts()
        return any(x.lower() in t for x in labels)
