from __future__ import annotations
from pathlib import Path
import os
import pyautogui
import pytesseract
from pytesseract import Output
from rapidfuzz import fuzz
from captionbrain.config import RESOURCES

class ScreenOCR:
    def __init__(self):
        bundled=RESOURCES/"tesseract"/"tesseract.exe"
        if bundled.exists(): pytesseract.pytesseract.tesseract_cmd=str(bundled)

    def words(self):
        img=pyautogui.screenshot()
        data=pytesseract.image_to_data(img,output_type=Output.DICT,config="--psm 6")
        out=[]
        for i,txt in enumerate(data.get("text",[])):
            txt=(txt or "").strip()
            if not txt: continue
            out.append({"text":txt,"rect":[data["left"][i],data["top"][i],data["left"][i]+data["width"][i],data["top"][i]+data["height"][i]],"conf":float(data["conf"][i]) if str(data["conf"][i]).replace('.','',1).lstrip('-').isdigit() else -1})
        return out

    def find(self, labels, threshold=82):
        labels=[labels] if isinstance(labels,str) else list(labels)
        best=None; bs=-1
        for w in self.words():
            for label in labels:
                s=fuzz.ratio(w["text"].lower(),label.lower())
                if s>bs: best=w; bs=s
        return (best,bs) if best and bs>=threshold else (None,bs)
