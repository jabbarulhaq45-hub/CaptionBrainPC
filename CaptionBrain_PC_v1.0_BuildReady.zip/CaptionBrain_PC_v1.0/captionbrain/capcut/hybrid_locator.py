from __future__ import annotations
from captionbrain.capcut.uia import UIABridge
from captionbrain.capcut.screen_ocr import ScreenOCR

class HybridLocator:
    def __init__(self, calibration=None):
        self.uia=UIABridge(); self.ocr=ScreenOCR(); self.calibration=calibration or {}

    def locate(self, key, labels):
        c,score=self.uia.find(labels)
        if c: return {"source":"uia","rect":c["rect"],"name":c["name"],"score":score}
        try:
            o,score=self.ocr.find(labels)
            if o: return {"source":"ocr","rect":o["rect"],"name":o["text"],"score":score}
        except Exception:
            pass
        saved=(self.calibration.get("controls") or {}).get(key)
        if saved: return {"source":"calibration","rect":saved.get("rect"),"name":saved.get("name",key),"score":100}
        return None
