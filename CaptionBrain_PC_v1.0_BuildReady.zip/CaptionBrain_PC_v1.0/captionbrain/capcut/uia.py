from __future__ import annotations
import time, re
from rapidfuzz import fuzz
from pywinauto import Desktop

class UIABridge:
    def __init__(self):
        self.window=None

    def connect(self, timeout=20):
        end=time.time()+timeout
        last=None
        while time.time()<end:
            wins=Desktop(backend="uia").windows()
            for w in wins:
                try:
                    title=w.window_text() or ""
                    if "capcut" in title.lower():
                        self.window=w
                        return w
                except Exception as e: last=e
            time.sleep(0.5)
        raise RuntimeError(f"CapCut window not found: {last}")

    def snapshot_controls(self, max_depth=5):
        if not self.window: self.connect()
        out=[]
        try:
            controls=self.window.descendants()
        except Exception:
            controls=[]
        for c in controls[:4000]:
            try:
                r=c.rectangle()
                out.append({
                    "name":c.window_text() or "",
                    "type":c.element_info.control_type or "",
                    "auto_id":c.element_info.automation_id or "",
                    "rect":[r.left,r.top,r.right,r.bottom],
                    "enabled":bool(c.is_enabled()),
                    "visible":bool(c.is_visible()),
                })
            except Exception:
                continue
        return out

    def find(self, labels, types=None, threshold=86):
        labels=[labels] if isinstance(labels,str) else list(labels)
        controls=self.snapshot_controls()
        best=None; best_score=-1
        for c in controls:
            if types and c["type"] not in types: continue
            name=(c["name"] or "").strip()
            if not name: continue
            for label in labels:
                score=fuzz.ratio(name.lower(),label.lower())
                if score>best_score:
                    best=(c,label); best_score=score
        return (best[0],best_score) if best and best_score>=threshold else (None,best_score)
