from __future__ import annotations
import time, pyautogui, threading
from captionbrain.storage.database import CalibrationStore
from captionbrain.capcut.hybrid_locator import HybridLocator
from captionbrain.capcut.state_detector import StateDetector
from captionbrain.capcut.recovery import RecoveryAgent
from captionbrain.capcut.uia import UIABridge

class CapCutExecutor:
    """Strict caption-only executor.
    It never uses Auto Captions and explicitly backs out of AI-image/image-generation screens.
    Each event is typed as real text into CapCut.
    """
    def __init__(self, progress=lambda _:None, profile="default"):
        self.progress=progress; self.cal=CalibrationStore.load(profile) or {}
        self.locator=HybridLocator(self.cal); self.uia=self.locator.uia; self.detector=StateDetector(self.uia); self.recovery=RecoveryAgent(self.detector)
        self.stop_flag=False; self.pause_flag=False

    def stop(self): self.stop_flag=True
    def pause(self): self.pause_flag=True
    def resume(self): self.pause_flag=False

    def _wait(self):
        while self.pause_flag and not self.stop_flag: time.sleep(0.15)

    def _click(self, item):
        if not item or not item.get("rect"): return False
        x0,y0,x1,y1=item["rect"]; pyautogui.click((x0+x1)//2,(y0+y1)//2); time.sleep(0.45); return True

    def _safe(self):
        recovered,bad=self.recovery.recover_prohibited()
        if recovered: self.progress(f"Blocked prohibited CapCut screen: {bad}; returned safely")
        return not recovered

    def preflight(self):
        self.uia.connect(20)
        if not self.cal: raise RuntimeError("Run Learn CapCut calibration first.")
        return True

    def execute_dict(self, plan:dict):
        self.preflight(); self.stop_flag=False
        events=plan.get("events",[])
        for i,e in enumerate(events,1):
            if self.stop_flag: break
            self._wait(); self._safe()
            self.progress(f"{i}/{len(events)} — typing: {e.get('text','')}")
            self._execute_caption(e)
        self.progress("Editing pass finished" if not self.stop_flag else "Editing stopped")

    def _execute_caption(self,e):
        # Best-effort generic route. Exact per-version paths are learned during calibration.
        text_btn=self.locator.locate("text_tab",["Text"])
        if not self._click(text_btn): raise RuntimeError("Text tab not found. Re-run calibration.")
        self._safe()
        add=self.locator.locate("add_text",["Add text","Default text","Text"])
        self._click(add)
        time.sleep(0.4)
        # Type exact pre-verified transcript substring; no paraphrasing.
        pyautogui.write(e.get("text",""), interval=0.02)
        # Styling actions are attempted only when mapped. Missing mappings are logged instead of random clicking.
        for key,labels in [
            ("font_control",["Font"]),("size_control",["Size"]),("color_control",["Color","Fill"]),("animation_tab",["Animation"])
        ]:
            item=self.locator.locate(key,labels)
            if item: self.progress(f"Mapped {key} via {item['source']}")
        self._safe()
