from __future__ import annotations
from pathlib import Path
import cv2, numpy as np
from captionbrain.config import CACHE_DIR

class DemoGenerator:
    def create(self, seconds=30, fps=30):
        out=CACHE_DIR/"CaptionBrain_Calibration_30s.mp4"
        w,h=1280,720
        vw=cv2.VideoWriter(str(out),cv2.VideoWriter_fourcc(*'mp4v'),fps,(w,h))
        total=seconds*fps
        for i in range(total):
            t=i/fps
            phase=int(t//10)
            if phase==0: frame=np.zeros((h,w,3),dtype=np.uint8)
            elif phase==1: frame=np.ones((h,w,3),dtype=np.uint8)*245
            else:
                x=np.linspace(0,1,w,dtype=np.float32)[None,:,None]
                left=np.array([40,40,40],dtype=np.float32); right=np.array([230,230,230],dtype=np.float32)
                row=(left*(1-x)+right*x).astype(np.uint8)
                frame=np.tile(row,(h,1,1))
            cv2.putText(frame,"CaptionBrain Calibration",(50,675),cv2.FONT_HERSHEY_SIMPLEX,1,(128,128,128),2,cv2.LINE_AA)
            vw.write(frame)
        vw.release(); return str(out)
