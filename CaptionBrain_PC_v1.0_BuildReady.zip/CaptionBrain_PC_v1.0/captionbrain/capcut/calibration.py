from __future__ import annotations
import json, time, pyautogui
from captionbrain.capcut.launcher import CapCutLauncher
from captionbrain.capcut.uia import UIABridge
from captionbrain.capcut.screen_ocr import ScreenOCR
from captionbrain.capcut.demo_generator import DemoGenerator
from captionbrain.storage.database import CalibrationStore
from captionbrain.config import CALIBRATION_TARGETS

class CalibrationEngine:
    """One-time self-learning map for the user's installed CapCut.
    Priority: Windows UI Automation -> OCR labels -> saved anchors.
    It also performs a safe smoke-test on a generated 30-second demo asset.
    """
    def __init__(self, progress=lambda _ : None):
        self.progress=progress; self.launcher=CapCutLauncher(); self.uia=UIABridge(); self.ocr=ScreenOCR()

    @staticmethod
    def _center(rect):
        x0,y0,x1,y1=rect; return ((x0+x1)//2,(y0+y1)//2)

    def _click(self, item):
        if not item or not item.get("rect"): return False
        pyautogui.click(*self._center(item["rect"])); time.sleep(0.8); return True

    def _map_targets(self):
        targets=json.loads(CALIBRATION_TARGETS.read_text(encoding="utf-8"))
        controls={}; full=self.uia.snapshot_controls()
        for idx,t in enumerate(targets["targets"],1):
            labels=t["labels"]; c,score=self.uia.find(labels,threshold=80); source="uia"
            if not c:
                try:
                    o,score=self.ocr.find(labels,threshold=78)
                    if o: c={"name":o["text"],"rect":o["rect"],"type":"OCR"}; source="ocr"
                except Exception: pass
            if c:
                controls[t["key"]]={"name":c.get("name",t["key"]),"rect":c.get("rect"),"source":source,"score":score,"labels":labels}
            self.progress(f"Mapping {idx}/{len(targets['targets'])}: {t['key']} {'✓' if c else 'not found'}")
        return targets,controls,full

    def _demo_smoke_test(self, controls, demo_asset):
        results=[]
        def step(name, fn):
            try:
                ok=bool(fn()); results.append({"step":name,"pass":ok}); self.progress(f"Demo test: {name} {'✓' if ok else 'SKIP'}"); return ok
            except Exception as e:
                results.append({"step":name,"pass":False,"error":str(e)}); self.progress(f"Demo test: {name} failed safely"); return False

        # Only verified controls are clicked. No guessed image-generation paths.
        step("new_project", lambda: self._click(controls.get("new_project")))
        time.sleep(1.5)
        # Remap after project screen changes.
        _,fresh,_=self._map_targets(); controls.update(fresh)
        def import_demo():
            if not self._click(controls.get("import_media")): return False
            time.sleep(1)
            # Windows file chooser usually accepts a pasted full path when the filename field is focused.
            pyautogui.write(demo_asset, interval=0.001); pyautogui.press('enter'); time.sleep(3)
            return True
        step("import_30s_demo", import_demo)
        _,fresh,_=self._map_targets(); controls.update(fresh)
        def create_text():
            if not self._click(controls.get("text_tab")): return False
            _,fresh2,_=self._map_targets(); controls.update(fresh2)
            if not self._click(controls.get("add_text")): return False
            time.sleep(0.5); pyautogui.write("CAPTIONBRAIN CALIBRATION", interval=0.03); time.sleep(0.6); return True
        step("create_real_text_layer", create_text)
        # Presence checks for high-value controls prove the app can at least see them before real editing.
        for key in ["font_control","size_control","color_control","animation_tab","keyframe","graph","transform_control"]:
            step("detect_"+key, lambda k=key: controls.get(k) is not None)
        return results,controls

    def run(self, profile="default"):
        self.progress("Launching CapCut…")
        self.launcher.launch(); self.uia.connect(30)
        targets,controls,full=self._map_targets()
        demo=DemoGenerator().create()
        self.progress("Running safe 30-second demo smoke-test…")
        demo_results,controls=self._demo_smoke_test(controls,demo)
        passed=sum(1 for x in demo_results if x.get("pass"))
        data={
            "version":2,"created":time.time(),"controls":controls,"all_controls":full[:1500],"demo_asset":demo,
            "targets_total":len(targets["targets"]),"targets_found":len(controls),
            "demo_results":demo_results,"demo_passed":passed,"demo_total":len(demo_results),
            "status":"CALIBRATED" if len(controls)>=8 and passed>=3 else "PARTIAL"
        }
        CalibrationStore.save(data,profile)
        self.progress(f"Calibration saved: {len(controls)}/{len(targets['targets'])} controls mapped; demo {passed}/{len(demo_results)} checks passed")
        return data
