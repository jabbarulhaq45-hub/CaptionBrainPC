from __future__ import annotations
import pyautogui, time

class RecoveryAgent:
    def __init__(self, detector): self.detector=detector
    def recover_prohibited(self):
        bad=self.detector.prohibited_state()
        if bad:
            pyautogui.press('esc'); time.sleep(0.5)
            if self.detector.prohibited_state(): pyautogui.hotkey('alt','left'); time.sleep(0.8)
            return True,bad
        return False,None
