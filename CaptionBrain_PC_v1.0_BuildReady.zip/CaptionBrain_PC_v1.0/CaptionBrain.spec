# -*- mode: python ; coding: utf-8 -*-
from PyInstaller.utils.hooks import collect_all
from pathlib import Path

root = Path(SPECPATH)
datas = [
    (str(root/'assets'), 'assets'),
    (str(root/'resources'), 'resources'),
]
binaries=[]; hiddenimports=[]
for pkg in ['ctranslate2','faster_whisper','tokenizers','PySide6','cv2','pytesseract','pywinauto','imageio_ffmpeg']:
    try:
        d,b,h=collect_all(pkg); datas+=d; binaries+=b; hiddenimports+=h
    except Exception:
        pass

a = Analysis(['main.py'], pathex=[str(root)], binaries=binaries, datas=datas, hiddenimports=hiddenimports,
             noarchive=False)
pyz = PYZ(a.pure)
exe = EXE(pyz, a.scripts, [], exclude_binaries=True, name='CaptionBrain', console=False, debug=False,
          bootloader_ignore_signals=False, strip=False, upx=True)
coll = COLLECT(exe, a.binaries, a.datas, strip=False, upx=True, name='CaptionBrain')
