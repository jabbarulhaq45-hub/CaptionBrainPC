$ErrorActionPreference = "Stop"
python -m pip install --upgrade pip
pip install -r requirements.txt
python -m pytest -q
pyinstaller CaptionBrain.spec --noconfirm
Write-Host "Portable build created under dist\CaptionBrain"
