# CaptionBrain PC v1.0 — Full Functional Specification

## 1. User-visible flow
1. Launch CaptionBrain.
2. Run **CapCut Learn** on first install or after a major CapCut update.
3. CaptionBrain launches CapCut and maps required controls with Windows UI Automation, OCR, and saved anchors.
4. CaptionBrain generates a 30-second calibration video and performs a safe demo smoke-test.
5. User imports the finished video into CaptionBrain.
6. CaptionBrain analyzes the full audio and samples the full visual runtime.
7. Audio is transcribed locally with multilingual Whisper and verified with a second transcription pass.
8. The transcript is split into short exact phrases/words. CaptionBrain never invents/paraphrases displayed caption text.
9. Scenes, brightness, clutter, face boxes, and safe text zones are analyzed.
10. Specialist agents choose typography, font role, size, color, accent, layout, position, motion, and effect.
11. Director Agent combines all decisions into a persistent Edit Plan.
12. Quality Agent rejects plans that do not use exact transcript substrings or violate basic readability rules.
13. Status becomes **READY FOR CAPCUT**.
14. User places the same video in CapCut Desktop.
15. User presses **START AI EDITING**.
16. CaptionBrain connects to the calibrated CapCut UI.
17. It opens the Text workflow and creates real editable text layers. It does not use Auto Captions as the final method.
18. It types the exact planned words, applies the mapped styling path, and verifies screen state.
19. Strict mode backs out of AI Image/Text-to-Image screens.
20. User can Pause, Resume, or Stop.

## 2. Specialist agents
- Voice/Timing Agent
- Transcript Verification Agent
- Scene Agent
- Visual Safe-Zone Agent
- Text Selector
- Typography Agent
- Font Agent
- Color Agent
- Layout Agent
- Motion Agent
- Overlay Agent
- Director Agent
- Quality Agent
- CapCut Launcher
- UI Automation Locator
- OCR Locator
- Calibration Agent
- CapCut Operator
- Recovery Agent

## 3. CapCut calibration targets
The first profile attempts to discover 32 controls:
New Project, Import, Text, Add Text, Font, Size, Color/Fill, Stroke, Shadow, Background, Opacity, Transform, Position, Scale, Rotation, Animation, In, Out, Loop, Effects, Keyframe, Graph/Easing, Copy, Paste, Undo, Redo, Timeline, Timecode, Preview, Export, Settings, Close/Back.

## 4. Tutorial knowledge integrated
All knowledge from Tutorials 001–005 is stored as structured JSON and backed up by the Master Tutorial Brain PDF.

### Typography / style families
- Clean Editorial
- Clean Blue
- Error / Red Glow / Strike
- Apple Minimal
- Stacked Kinetic
- Gradient Title
- Highlighter
- Shine Sweep
- Flicker
- Premium Purple
- Glow Slide Up
- Cursor / Typing Motif
- Cluster
- Straight Line
- One-on-One
- Diagrammatic

### Editing principles
- voiceover is the timing master;
- use independent real text layers;
- short phrase/important-word captioning;
- semantic hierarchy through size/weight/color;
- selective accent colors;
- multi-layer compositions;
- keyframes + easing/graph;
- optional blur/glow/highlight/strike/shine layers;
- negative-space placement;
- avoid faces/subjects;
- verify each important CapCut state;
- do not random-click when a control is missing.

## 5. Transcript accuracy strategy
- multilingual Faster-Whisper Small bundled in the Windows build;
- word timestamps enabled;
- VAD enabled;
- beam search;
- two-pass transcription with different previous-text conditioning;
- confidence retained on words/segments;
- caption text constrained to exact transcript words;
- larger model choices (medium / large-v3) exposed in Settings for later installation.

No speech-recognition system can honestly guarantee 100% accuracy on every ambiguous recording. The app is designed to maximize automatic verification and never claim certainty that the model does not have.

## 6. Visual analysis
- whole-runtime sampling rather than first-seconds-only analysis;
- scene-change estimation using histogram distance;
- brightness measurement;
- edge-density / clutter measurement;
- face detection;
- eight candidate text zones scored by clutter and face collision;
- safe-zone passed to layout planner.

## 7. CapCut UI learning strategy
Priority order:
1. Windows UI Automation element name/control type/automation ID.
2. OCR label detection via bundled Tesseract.
3. Stored calibration anchor from the user's machine.
4. Raw coordinate only as a last-resort calibrated fact.

The app stores the learned profile in `%LOCALAPPDATA%\CaptionBrain\calibration` and can re-learn after updates.

## 8. 30-second calibration demo
The generated media contains black, white, and gradient sections so contrast/placement logic can be tested. The bundled demo script includes Clean Blue, Error, Apple Minimal, Stacked Kinetic, Highlighter, Premium Purple, Glow Slide Up, and Cursor Type examples.

The first build performs a safe smoke test: new project when detectable, demo import when detectable, real text-layer creation, and visibility checks for font, size, color, animation, keyframe, graph/easing, and transform controls.

## 9. Safety / recovery
- strict caption-only mode ON by default;
- prohibited states include AI Image, Text to Image, Image Generator, and similar screens;
- Escape/back navigation is used to recover;
- missing controls are logged instead of guessed;
- stop/pause/resume controls;
- calibration profile is machine-specific;
- no deletion/export/cloud operations are required during calibration.

## 10. Hardware behavior
- Windows 10/11 x64.
- NVIDIA CUDA is preferred automatically when CTranslate2 detects it.
- CPU INT8 is the fallback.
- Small multilingual model is bundled by CI; larger models can be added.
- The architecture is local-first and does not require a cloud AI service for core analysis.

## 11. First-version validation requirement
A Windows executable can be produced by the included GitHub Actions workflow. The application must then be tested against the user's exact CapCut Desktop version. Because CapCut is a third-party application with no public full editing-automation API, it is not technically honest to label the system "100% working" before the calibration demo and a real end-to-end project pass succeed on that installation.
