# CaptionBrain PC v1.0 — Build-Ready Windows Project

## Product goal
CaptionBrain analyzes the same finished video that the user will later place in CapCut Desktop. Analysis happens before editing. Once the plan is READY, the user opens the same video in CapCut and presses **START AI EDITING**. CaptionBrain then types real text layers into CapCut and styles them. **Auto Captions are not used as the final caption method.**

## Daily workflow
1. Import the finished video into CaptionBrain.
2. Press **Analyze Full Video**.
3. CaptionBrain extracts audio, runs two-pass local Whisper transcription, samples visuals, detects scenes/faces/safe zones and builds an Edit Plan.
4. When status becomes **READY FOR CAPCUT**, open the same video in a CapCut project.
5. Press **START AI EDITING**.
6. CaptionBrain uses its saved CapCut calibration map to create actual text objects, type exact transcript words, and apply the planned typography/motion choices.

## First-run CapCut Learn mode
Run **CapCut Learn** once after installation and again after major CapCut updates.

Learn mode:
- launches the installed CapCut or its shortcut;
- inventories the Windows UI Automation tree;
- falls back to OCR for visible labels;
- maps 32 editing controls such as Text, Add Text, Font, Size, Color, Animation, Keyframe, Graph/Easing, Transform and Timeline;
- generates a 30-second calibration media asset with black, white and gradient sections;
- saves the per-machine control map under `%LOCALAPPDATA%\CaptionBrain\calibration`.

The architecture intentionally uses **UI Automation first, OCR second, calibrated anchors third**. Raw coordinates are last-resort data, not the primary mechanism.

## Five tutorial videos built into the brain
The package includes a structured knowledge database plus the combined Master Tutorial Brain PDF. The current recipe library includes:
- Clean Editorial / Clean Blue
- Error / red glow / strike
- Apple Minimal
- Stacked word-by-word kinetic captions
- Gradient title
- Highlighter bar
- Shine sweep
- Flicker
- Premium Purple
- Glow Slide Up
- Cursor / typing motif
- Cluster, Straight Line, One-on-One and Diagrammatic layouts
- typography hierarchy, selective accent colors, keyframes, graph/easing, blur/glow, layer order and safe-zone placement

## Specialist-brain architecture
The planner is deliberately split into specialist roles:
- Voice/Timing Agent
- Transcript Verification Agent
- Scene/Visual Agent
- Text Selector
- Typography Agent
- Font Agent
- Color Agent
- Layout Agent
- Motion Agent
- Overlay Agent
- Director Agent
- Quality Agent
- CapCut Locator / Operator
- Recovery Agent

A single Director assembles their decisions into a saved edit plan before CapCut execution starts.

## Transcript policy
The current planner never paraphrases displayed caption text. Displayed words must be exact words from the transcript. Two Whisper passes are compared for additional verification. No speech-recognition system can honestly guarantee 100% correctness on every unclear recording; CaptionBrain therefore stores confidence and performs maximum automatic verification rather than falsely claiming certainty.

The bundled model in the Windows build is multilingual **faster-whisper-small**. Settings also support `medium` and `large-v3` if the user later installs larger models for higher transcription quality.

## Hardware
- Windows 10/11 x64
- CPU fallback: CTranslate2 INT8
- NVIDIA CUDA GPU: automatically preferred when available
- RAM: 8 GB minimum, 16 GB+ recommended
- Disk: installer can be several hundred MB because the multilingual speech model and OCR engine are bundled

## Safety / recovery rules
- Strict caption-only mode is ON by default.
- The operator explicitly detects AI Image / Text-to-Image / image-generator screens and backs out.
- Missing controls are logged instead of triggering random clicks.
- Every machine stores its own calibration profile.
- Pause / Resume / Stop controls are available during execution.

## Important first-version boundary
This repository implements the full **architecture and first functional Windows build path**, but CapCut is a third-party application without a public editing automation API. Exact styling execution depends on what the installed CapCut version exposes through Windows UI Automation/OCR. The first calibration/demo run is therefore part of deployment and testing, not an optional cosmetic step.

The project should not be described as "100% guaranteed" before it passes the calibration demo and end-to-end tests on the user's exact CapCut Desktop build.

## Build locally
Requires Python 3.11 on Windows:

```powershell
./build.ps1
```

## Build automatically on GitHub
Upload this project to a GitHub repository. The included `.github/workflows/build-windows.yml` builds:
- `CaptionBrain-Setup-v1.0.0.exe`
- `CaptionBrain-Portable-v1.0.0.zip`

The CI build also downloads the multilingual Whisper Small model and bundles Tesseract OCR.
