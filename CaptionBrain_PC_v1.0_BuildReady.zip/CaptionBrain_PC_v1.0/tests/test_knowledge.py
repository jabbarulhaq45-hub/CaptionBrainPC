import json
from captionbrain.config import KNOWLEDGE_FILE, STYLE_FILE, CALIBRATION_TARGETS

def test_knowledge_files_load():
    assert json.loads(KNOWLEDGE_FILE.read_text())["source_tutorials"]==[1,2,3,4,5]
    assert len(json.loads(STYLE_FILE.read_text())["recipes"])>=10
    assert len(json.loads(CALIBRATION_TARGETS.read_text())["targets"])>=25
