from captionbrain.models import TranscriptSegment, WordToken
from captionbrain.brains.director import DirectorAgent

def test_exact_transcript_text_only():
    s=TranscriptSegment(0,2,"This mistake can destroy your entire project",[
        WordToken("This",0,0.2),WordToken("mistake",0.2,0.6),WordToken("can",0.6,0.8),WordToken("destroy",0.8,1.2),WordToken("your",1.2,1.4),WordToken("entire",1.4,1.7),WordToken("project",1.7,2.0)
    ])
    ev=DirectorAgent().plan([s],[],2)[0]
    assert ev.qa["exact_transcript_substring"]
    assert all(w.lower() in s.text.lower() for w in ev.text.split())
